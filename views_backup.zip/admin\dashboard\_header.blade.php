<div class="">
    <h1 class="text-2xl font-bold text-gray-900 dark:text-gray-100">Welcome back, {{ auth()->user()->name }}!</h1>
</div>
