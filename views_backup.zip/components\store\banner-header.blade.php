@props([
    'seller',
    'logoClass' => 'w-24 h-24',        // small for index
    'bannerClass' => 'h-28',           // small banner for index
    'bannerFontClass' => 'text-xl',
    'logoOffset' => '-bottom-12',      // offset for centering
])

<div class="relative mb-8">
    <div class="{{ $bannerClass }} w-full overflow-hidden flex items-center justify-center rounded-lg
        @if(!$seller->banner_image)
            bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500
            dark:bg-gradient-to-r dark:from-gray-800 dark:via-gray-700 dark:to-gray-600
        @endif">
        @if($seller->banner_image)
            <img src="{{ asset('storage/'.$seller->banner_image) }}"
                alt="{{ $seller->store_name ?? $seller->name }} Banner"
                class="w-full h-full object-cover" />
        @else
            <span class="text-white dark:text-gray-300 tracking-wide {{ $bannerFontClass }} font-medium">
                Store Banner
            </span>
        @endif
    </div>
    <!-- Store Logo: overlaps banner -->
    <div class="absolute left-1/2 transform -translate-x-1/2 {{ $logoOffset }} z-10">
        <img src="{{ $seller->store_logo_url ?? 'https://ui-avatars.com/api/?name='.urlencode($seller->store_name ?? $seller->name) }}"
            alt="{{ $seller->store_name ?? $seller->name }}"
            class="{{ $logoClass }} rounded-full border-4 border-white dark:border-gray-800 shadow-xl bg-white dark:bg-gray-800 object-cover" />
    </div>
</div>