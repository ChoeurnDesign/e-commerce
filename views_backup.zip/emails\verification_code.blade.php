<!DOCTYPE html>
<html>
<head>
    <title>Verification Code</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your verification code is: <strong>{{ $code }}</strong></p>
    <p>Please enter this code to verify your email address.</p>
    <p>Thank you!</p>
</body>
</html>
