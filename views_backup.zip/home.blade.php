<x-app-layout>

    <x-home.banner-slider :banners="$banners" />

    <x-home.categories-preview :parentCategories="$parentCategories" />

    <x-home.featured-products :featuredProducts="$featuredProducts" />

    <x-home.trust-section />

</x-app-layout>
