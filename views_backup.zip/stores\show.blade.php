<x-app-layout>
    <x-slot name="header">
        <meta name="csrf-token" content="{{ csrf_token() }}">
    </x-slot>
    <div class="py-8 bg-gray-200 dark:bg-gray-900 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            {{-- Store Banner/Header --}}
            <x-store.banner-header 
                :seller="$seller" 
                logoClass="w-44 h-44" 
                bannerClass="h-72" 
                bannerFontClass="text-4xl" 
                logoOffset="-bottom-24"
            />

            <!-- Store Info Card -->
            <div class="pt-20 pb-8 text-center">
                <h1 class="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
                    {{ $seller->store_name ?? $seller->name }}
                </h1>
                <p class="text-gray-600 dark:text-gray-300 mb-1">{{ $seller->description ?? 'No description provided.' }}</p>
                <div class="flex flex-wrap justify-center gap-3 mt-2 items-center">
                    <span class="inline-block bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 px-4 py-1 rounded-full font-semibold">
                        {{ $seller->products_count ?? $seller->products()->count() }} Products
                    </span>
                    <span class="inline-block bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300 px-4 py-1 rounded-full font-semibold">
                        Followers: {{ $seller->followers_count ?? 0 }}
                    </span>
                    
                    @php
                        $hasReviewed = auth()->check() && auth()->user()->hasReviewedStore($seller->id);
                    @endphp
                    
                    @if(auth()->check())
                        @if(!$hasReviewed)
                            <button 
                                onclick="document.dispatchEvent(new CustomEvent('show-store-review'))"
                                class="inline-block bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-1 rounded-full font-semibold shadow"
                            >Add Review</button>
                        @else
                            <span class="inline-block bg-green-500 text-white px-4 py-1 rounded-full font-semibold flex items-center gap-1">
                                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path>
                                </svg>
                                Reviewed
                            </span>
                        @endif
                    @else
                        <button 
                            onclick="window.location.href='{{ route('login') }}'"
                            class="inline-block bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-1 rounded-full font-semibold shadow"
                        >Add Review</button>
                    @endif
                    
                    <span class="inline-block bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 px-4 py-1 rounded-full font-semibold">
                        Opened: {{ $seller->created_at->format('Y-m-d') }}
                    </span>
                </div>
                <div class="flex flex-wrap justify-center gap-8 mt-4 text-sm">
                    <div>
                        <strong>Email:</strong> {{ $seller->contact_email ?? 'N/A' }}
                    </div>
                    <div>
                        <strong>Location:</strong> {{ $seller->location ?? 'Not specified' }}
                    </div>
                </div>
            </div>

            <!-- Show success/error messages -->
            @if(session('success'))
                <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
                    {{ session('success') }}
                </div>
            @endif

            @if(session('error'))
                <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                    {{ session('error') }}
                </div>
            @endif

            <!-- Review Form - Only show if not reviewed -->
            @auth
            @if(!$hasReviewed)
            <div 
                id="review-form-container"
                x-data="{ show: false, selectedRating: 0 }" 
                x-init="
                    document.addEventListener('show-store-review', function() {
                        show = true;
                    })
                "
                x-show="show"
                style="display: none;"
                class="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
                <div class="absolute inset-0 bg-black bg-opacity-50" @click="show = false"></div>
                
                <div class="w-full max-w-md bg-gray-800 rounded-lg shadow-xl relative">
                    <!-- Header -->
                    <div class="bg-gray-700 px-6 py-4 rounded-t-lg">
                        <div class="flex items-center justify-between">
                            <div class="text-white">
                                <h3 class="text-lg font-semibold">Add Review</h3>
                                <p class="text-sm text-gray-300">To "{{ $seller->store_name ?? $seller->name }}"</p>
                            </div>
                            <button @click="show = false" class="text-white text-xl hover:text-gray-300">✕</button>
                        </div>
                    </div>

                    <!-- Form -->
                    <div class="p-6">
                        <form action="{{ route('store-reviews.store', $seller) }}" method="POST">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            
                            <div class="mb-4">
                                <label class="block text-gray-300 text-sm mb-3">How would you rate this store?</label>
                                
                                <!-- Star Rating -->
                                <div class="flex items-center gap-1 mb-2">
                                    @for($i = 1; $i <= 5; $i++)
                                        <button type="button" 
                                                @click="selectedRating = {{ $i }}"
                                                class="text-2xl transition-colors duration-200">
                                            <span x-show="selectedRating >= {{ $i }}" class="text-yellow-400">
                                                <x-icon-nav name="star-filled" class="h-8 w-8"/>
                                            </span>
                                            <span x-show="selectedRating < {{ $i }}" class="text-gray-500">
                                                <x-icon-nav name="star-empty" class="h-8 w-8"/>
                                            </span>
                                        </button>
                                    @endfor
                                </div>
                                
                                <!-- Hidden input for form submission -->
                                <input type="hidden" name="rating" :value="selectedRating" required>
                                
                                <div x-show="selectedRating === 0" class="text-red-400 text-sm mb-3">Please select a rating</div>
                            </div>

                            <div class="mb-6">
                                <label class="block text-gray-300 text-sm mb-2">Share your experience</label>
                                <textarea name="comment" rows="4" required 
                                          placeholder="Tell others about your experience with this store..."
                                          class="w-full bg-gray-700 text-gray-300 px-4 py-3 rounded border-0 resize-none focus:bg-gray-600 transition-colors"></textarea>
                            </div>

                            <div class="flex gap-3">
                                <button type="submit" 
                                        :disabled="selectedRating === 0"
                                        :class="selectedRating === 0 ? 'bg-gray-600 cursor-not-allowed' : 'bg-gray-600 hover:bg-gray-500'"
                                        class="flex-1 text-white py-2 rounded-full font-semibold transition-colors">
                                    Submit Review
                                </button>
                                <button type="button" @click="show = false" class="px-6 py-2 bg-gray-600 hover:bg-gray-500 text-white rounded-full transition-colors">
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            @endif
            @endauth

            {{-- Products Section --}}
            <div class="flex justify-between items-center mb-6 flex-wrap gap-4">
                <p class="text-gray-600 dark:text-gray-300 font-medium">
                    <span class="text-green-600 dark:text-green-400 font-semibold">
                        {{ $products->total() }}
                    </span>
                    products found in this store
                </p>
                <div class="text-sm text-gray-500 dark:text-gray-400 bg-gray-200 dark:bg-gray-800 px-4 py-2 rounded-full border border-gray-200 dark:border-gray-700">
                    Page {{ $products->currentPage() }} of {{ $products->lastPage() }}
                </div>
            </div>

            @if($products->count())
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
                    @foreach($products as $product)
                        <x-products.product-card :product="$product" />
                    @endforeach
                </div>
                <div class="flex justify-center">
                    {{ $products->links() }}
                </div>
            @else
                <div class="text-center py-16 bg-white dark:bg-gray-900 rounded-2xl shadow-md border border-gray-300 dark:border-gray-700">
                    <div class="text-6xl mb-4 text-gray-400 dark:text-gray-600">📦</div>
                    <h3 class="text-xl font-semibold text-gray-600 dark:text-gray-300 mb-4">
                        No Available Products Found
                    </h3>
                    <p class="text-gray-500 dark:text-gray-400 mb-6">
                        Try adjusting your filters or check back later.
                    </p>
                    <a href="{{ route('stores.index') }}"
                       class="bg-sky-600 hover:bg-sky-700 dark:bg-sky-700 dark:hover:bg-sky-600 text-white px-8 py-3 rounded-full font-medium transition-all shadow-md hover:shadow-lg">
                        View All Stores
                    </a>
                </div>
            @endif

            {{-- Store Ratings & Reviews --}}
            <x-store.reviews-grid 
                :seller="$seller" 
                :reviews="$seller->receivedStoreReviews()->latest()->take(6)->get()" 
            />
            
        </div>
    </div>
</x-app-layout>